#include "global.h"

#define BUFFER_SIZE 20

typedef union {
    struct {
        unsigned stagingFull:1;
        unsigned bufferLocked:1;       
    };
    uint8_t byte;
} tBufferFlags;

typedef struct {
    uint8_t *ptrWrite;
    uint8_t *ptrRead;
    uint8_t *ptrStart;
    uint8_t *ptrEnd;
    uint8_t fillLevel;
    uint8_t size;
    uint8_t data[BUFFER_SIZE];
} tRingBuffer;

typedef enum {
    BUFFER_OPERATION_OK,
    BUFFER_ERROR_EMPTY,
    BUFFER_ERROR_FULL,
    BUFFER_ERROR_LOCKED,
} eBufferResponse;

typedef enum {
    BUFFER_NONE,
    BUFFER_WAIT_FOR_STAGE,
    BUFFER_CHECK_FILL,
    BUFFER_LOCK,
    BUFFER_READ_FROM_STAGE,
    BUFFER_UNLOCK
} eBufferLoopState;

typedef struct {
    tRingBuffer buffer;
    eBufferLoopState state;
    tBufferFlags flags;
    volatile uint8_t stage;
} tBufferData;

tBufferData bufferRx;
tBufferData bufferTx;

//                             API Methods                                    //
void putByteRx(uint8_t byte, eBufferResponse *ptrStatus);
void putByteTx(uint8_t byte, eBufferResponse *ptrStatus);
uint8_t getByteRx(eBufferResponse *ptrStatus);
uint8_t getByteTx(eBufferResponse *ptrStatus);
uint8_t getRxDataByteCount(void);
uint8_t getTxDataByteCount(void);
void runRxTxStaging(void);
void setupBusBuffer(void);

//                             Common Methods                                 //
uint8_t getByte(eBufferResponse *ptrStatus, tBufferData *ptrBufferData);
void putByte(uint8_t byte, eBufferResponse *ptrStatus, tBufferData *ptrBufferData);
void runStaging(tBufferData *ptrBufferData);
void setupBuffer(tBufferData *ptrBufferData);

//----------------------------------------------------------------------------//
//                             API Methods                                    //
//----------------------------------------------------------------------------//
void setupBusBuffer(void) {
    setupBuffer(&bufferRx);
    setupBuffer(&bufferTx);
}

void putByteRx(uint8_t byte, eBufferResponse *ptrStatus) {
    putByte(byte, ptrStatus, &bufferRx);
}

void putByteTx(uint8_t byte, eBufferResponse *ptrStatus) {
    putByte(byte, ptrStatus, &bufferTx);
}

uint8_t getByteRx(eBufferResponse *ptrStatus) {
    return getByte(ptrStatus, &bufferRx);
}

uint8_t getByteTx(eBufferResponse *ptrStatus) {
    return getByte(ptrStatus, &bufferTx);
}

uint8_t getRxDataByteCount(void) {
    return bufferRx.buffer.fillLevel;
}

uint8_t getTxDataByteCount(void) {
    return bufferRx.buffer.fillLevel;
}


void runRxTxStaging(void) {
    runStaging(&bufferTx);
    runStaging(&bufferRx);
}

//----------------------------------------------------------------------------//
//                             Common Methods                                 //
//----------------------------------------------------------------------------//
void setupBuffer(tBufferData *ptrBufferData) {
    tRingBuffer *ptrBuffer = &(ptrBufferData->buffer);
    
    ptrBuffer -> ptrStart = &(ptrBuffer -> data[0]);
    ptrBuffer -> ptrEnd = &(ptrBuffer -> data[(BUFFER_SIZE - 1)]);
    ptrBuffer -> ptrRead = ptrBuffer -> ptrStart;
    ptrBuffer -> ptrWrite = ptrBuffer -> ptrStart;
    ptrBuffer -> fillLevel = 0;
    ptrBufferData -> flags.byte = 0;
    ptrBuffer -> size = BUFFER_SIZE;
    bufferRx.state = BUFFER_NONE;
}

void putByte(uint8_t byte, eBufferResponse *ptrStatus, tBufferData *ptrBufferData) {
    if(!ptrBufferData -> flags.stagingFull) {
        ptrBufferData -> stage = byte;
        ptrBufferData -> flags.stagingFull = 1;
        *ptrStatus = BUFFER_OPERATION_OK;
    } else {
        *ptrStatus = BUFFER_ERROR_FULL;
    }
}

uint8_t getByte(eBufferResponse *ptrStatus, tBufferData *ptrBufferData) {
    tRingBuffer *ptrBuffer = &(ptrBufferData->buffer);
    tBufferFlags *ptrFlags = &(ptrBufferData->flags);
    
    if(ptrBuffer -> fillLevel == 0) {
        *ptrStatus = BUFFER_ERROR_EMPTY;
        return 0;
    }
    if(ptrFlags -> bufferLocked) {
        *ptrStatus = BUFFER_ERROR_LOCKED;
        return 0;
    }
    ptrFlags -> bufferLocked = 1;
    uint8_t byte = *(ptrBuffer -> ptrRead);
    
    ptrBuffer -> ptrRead++;
    ptrBuffer -> fillLevel--;
    
    if(ptrBuffer -> ptrRead > ptrBuffer -> ptrEnd) {
        ptrBuffer -> ptrRead = ptrBuffer -> ptrStart;
    }
    
    ptrFlags -> bufferLocked = 0;
    
    ptrStatus = BUFFER_OPERATION_OK;
    return byte;
}

void runStaging(tBufferData *ptrBufferData) {
    eBufferLoopState *ptrState = &(ptrBufferData->state);
    tBufferFlags *ptrFlags = &(ptrBufferData->flags);
    tRingBuffer *ptrBuffer = &(ptrBufferData->buffer);
    
    switch (*ptrState) {
        case BUFFER_NONE:
            *ptrState = BUFFER_WAIT_FOR_STAGE;
        case BUFFER_WAIT_FOR_STAGE:
            if(!ptrFlags -> stagingFull) {
                return;
            }
            *ptrState = BUFFER_CHECK_FILL;
            break;
            
        case BUFFER_CHECK_FILL:
            if(ptrBuffer -> fillLevel >= ptrBuffer -> size){
                break;
            }
            *ptrState = BUFFER_LOCK;
            break;
            
        case BUFFER_LOCK:
            if(ptrFlags -> bufferLocked) {
                break;
            }
            ptrFlags -> bufferLocked = 1;
            *ptrState = BUFFER_READ_FROM_STAGE;
            break;
            
        case BUFFER_READ_FROM_STAGE:
            *(ptrBuffer -> ptrWrite) = ptrBufferData -> stage;
            ptrBuffer -> fillLevel++;
            ptrBuffer -> ptrWrite++;
            
            if(ptrBuffer -> ptrWrite > ptrBuffer -> ptrEnd) {
                ptrBuffer -> ptrWrite = ptrBuffer -> ptrStart;
            }
            
            ptrBufferData -> stage = 0;
            ptrFlags -> stagingFull=0;
            *ptrState = BUFFER_UNLOCK;
            break;
            
        case BUFFER_UNLOCK:
            ptrFlags -> bufferLocked = 0;
            *ptrState = BUFFER_WAIT_FOR_STAGE;
            break;
    }
}