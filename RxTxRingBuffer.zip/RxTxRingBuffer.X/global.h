#ifndef GLOBAL_H
#define	GLOBAL_H
#include "xc.h"

#endif	/* GLOBAL_H */