#ifndef BUS_BUFFER_H
#define	BUS_BUFFER_H

#include <xc.h> // include processor files - each processor file is guarded.  

extern void putByteRx(uint8_t byte, eBufferResponse *ptrStatus);
extern void putByteTx(uint8_t byte, eBufferResponse *ptrStatus);
extern uint8_t getByteRx(eBufferResponse *ptrStatus);
extern uint8_t getByteTx(eBufferResponse *ptrStatus);
extern uint8_t getRxDataByteCount(void);
extern uint8_t getTxDataByteCount(void);
extern void runRxTxStaging(void);
extern void setupBusBuffer(void);

#endif	/* BUS_BUFFER_H */

